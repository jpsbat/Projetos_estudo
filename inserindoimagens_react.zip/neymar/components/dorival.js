import { Image, View, Text } from 'react-native';

export default function Dorival () {
  return (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Image
      style={{width: 350, height: 350, marginBottom: 10 }}
      source={require("../assets/Dorival_santos.jpg")}
    />
    <Text style={{ fontSize: 25, fontWeight: 'bold', color: 'red' }}> Dorivrau </Text>
  </View>
  );
}