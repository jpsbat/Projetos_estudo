import { View, Text, Image, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import Neymar from './components/neymar.js';
import Arboleda from './components/arboleda';
import Dorival from './components/dorival';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
  <Tab.Navigator>
    <Tab.Screen
      name="Neymar"
      component={Neymar}
      options={{
        tabBarLabel:"Neymar",
        tabBarIcon: () => (
          <Image
            style={{width: 30, height: 30}}
            source={require('./assets/Neymar-Al-Hilal-3.jpg')} />
        )
      }}
    />
    <Tab.Screen
      name="Arboleda"
      component={Arboleda}
      options={{
        tabBarLabel:"Arboleda",
        tabBarIcon: () => (
          <Image
            style={{width: 30, height: 30}}
            source={require('./assets/arboleda.jpg')} />
        )
      }}
    />
    <Tab.Screen
      name="Dorival"
      component={Dorival}
      options={{
        tabBarLabel:"Dorival",
        tabBarIcon: () => (
          <Image
            style={{width: 30, height: 30}}
            source={require('./assets/Dorival_santos.jpg')} />
        )
      }}
    />
  </Tab.Navigator>
</NavigationContainer>
  );
}
